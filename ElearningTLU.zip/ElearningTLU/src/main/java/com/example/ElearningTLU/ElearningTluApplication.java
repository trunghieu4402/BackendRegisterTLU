package com.example.ElearningTLU;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElearningTluApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElearningTluApplication.class, args);
	}

}
