package com.example.ElearningTLU;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearningTluApplicationTests {

	@Test
	void contextLoads() {
	}

}
